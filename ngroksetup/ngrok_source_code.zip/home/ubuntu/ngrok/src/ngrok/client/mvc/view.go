package mvc

type View interface {
	Shutdown()
}
